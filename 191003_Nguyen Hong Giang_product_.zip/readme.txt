/* This website is IsshoTabe, a website communication website that provides a video calling service for university students to hang out and socialize while eating. */


Overview of the project

- The index page of IsshoTabe (homepage) is home.html. Meanwhile, the landing page that explains the  (ideal) functions and features of the website is landing-page.html

- On the website, there are:
   + 1 homepage
   + 1 landing page introducing the main website 
   + 2 pages of a login page and a register page
   + 1 page for a texting chat feed 
   + 1 page listing the video chatrooms of the user
   + 1 subpage of the video chatroom 
	(please click on "Camping Club" in home.html or video-chat.html to access this page)
   + 1 page of prototyping the video call/meeting 
	(please click on "Start a meeting" from the "Camping Club" chatroom to go to this page)

- Due to my lack of coding skills, I apologize that apart from buttons that transition between pages, most of the functions on the website do not work properly, as they should (for example, logging in, creating an account, texting (in the chat feed),  or starting a video call). The website consists of visual design components and the presentations of functions only, and no back-end functions were programmed.

- Moreover, as the target users are laptop users, ideally in their laptop's full screen, most parts of this website are not responsive for mobile and tablet screens. I am sorry that the website's responsiveness has many rooms for improvement. 


Disclaimer:

- The photos used on the website are from Unsplash - a platform that grants full permission of using their images.

- The graphical illustrations on the website are my original ones.